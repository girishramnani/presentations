"""
in the code provided for this problem, your task is to fill up the ??? appropriately to solve the problem. Do not change more than 50 characters.

Dothraki are planning an attack to usurp King Robert's throne. King Robert learns of this conspiracy from Raven and plans to lock the single door through which the enemy can enter his kingdom.

door

But to lock the door he needs a key that is an anagram of a certain palindrome string.

The king has a string composed of lowercase English letters. Help him figure out whether any anagram of the string can be a palindrome or not.

Input Format

A single line which contains the input string.

Output Format

A single line which contains YES or NO.

Sample Input

aaabbbb

Sample Output

YES

Explanation

A palindrome permutation of the given string is bbaaabb.



Extra : convert this code to python 3

"""



s = input()
count = {}
for i in range(len(s)):
    if s[i] not in count: count[s[i]] = 0
    count[s[i]] += 1
isPalindrome = True
hasOdd = False
if (???): hasOdd = True
for k in count:
    if count[k] % 2 != 0:
        if hasOdd: hasOdd = False
        else:
            isPalindrome = False
            break
print("YES" if isPalindrome else "NO")
