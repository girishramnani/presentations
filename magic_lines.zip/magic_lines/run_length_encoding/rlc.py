"""

Given an input string, write a function that returns the Run Length Encoded string for the input string. For example, if the input string is “AABBBCCCC”, then the function should return “A2B3C4″.

But due to some technical problem he lost one line from his code. Can you complete the missing line?

The input string will consist of at most 100 uppercase English letters


Sample Input

AABBBCCCC

Sample Output

A2B3C4



"""


def encode(source):
      dest="";
      i=0
      while i<len(source):
         runLength = 1;
         ???
            runLength=runLength+1
            i=i+1
         dest+=source[i]
         dest+=str(runLength)
         i=i+1
      return dest


source=input()
print (encode(source))
