"""

You are given a code to sort some integers in an array in non-descending order. Unfortunately, one line is missing from the code, so it's not working. Can you fill the missing line?

Don't worry about input/output formatting. There will be at most 100 integers in the array.

Note that if you modify any other line except the line marked by "~~~Fill this line~~~", you will get Wrong Answer to this problem.


test:

5
1
9
6
4
1

output:

1
1
4
6
9


"""

def bubble_sort(seq):
    changed = True

    while True:
        ???
        changed = False
        for i in range(len(seq) - 1):
            if seq[i] > seq[i+1]:
                seq[i], seq[i+1] = seq[i+1], seq[i]
                changed = True
    return seq


if __name__ == "__main__":
   n=int(input())
   seq=[]
   for i in range (0,n):
      seq.append(int(input()))
   seq=bubble_sort(seq)
   for x in seq:
      print(x)

