
import re


import os
import shutil

import difflib


log=True
progFile = "bubble_sort.py"


def detect_input_files():

    files = []

    for file in os.listdir("."):
        data = re.search(r"input(\d\d)",file)
        if data:
            if log:
                print("file found {}".format(file))


            files.append((file,data.group(1)))

    return files

def check_difference(file1,file2):
    data1 = open(file1).read()
    data2 = open(file2).read()
    return data1 == data2


files = detect_input_files()


for file_name,index in files:
    if log:
        print("testing {}".format(file_name))
    os.system("python {} < {} > {}".format(progFile,file_name,"test_output"+index+".txt"))
    if check_difference("output"+index+".txt","test_output"+index+".txt"):
        print("\ttest passed")
