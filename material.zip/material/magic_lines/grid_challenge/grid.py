"""
Given a squared sized grid G of size N in which each cell has a lowercase letter. Denote the character in the ith row and in the jth column as G[i][j].

You can perform one operation as many times as you like: Swap two column adjacent characters in the same row G[i][j] and G[i][j+1] for all valid i,j.

Is it possible to rearrange the grid such that the following condition is true?

G[i][1]≤G[i][2]≤⋯≤G[i][N] for 1≤i≤N and
G[1][j]≤G[2][j]≤⋯≤G[N][j] for 1≤j≤N


Sample Input

1
5
ebacd
fghij
olmkn
trpqs
xywuv

Sample Output

YES

Explanation

The grid in the first and only testcase can be reordered to

abcde
fghij
klmno
pqrst
uvwxy




"""


for _ in range(int(input())):
    A = []
    ans = "YES"
    n = int(input())
    for i in range(n):
        A.append(input().strip())
    for i in range(n - 1):
        ???
        for j in range(n):
            if x[j] > y[j]:
                ans = "NO"
    print(ans)

