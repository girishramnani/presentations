"""There is an infinite integer grid where N people live in N different houses. They decide to create a meeting point at one person's house.

From any given cell, all 8 adjacent cells can be reached in 1 unit of time, e.g. (x,y) can be reached from (x-1,y+1) in one unit of time. Find a common meeting place which minimizes the combined travel time of everyone.

Your task will be to complete the code in the editor so that it solves the problem stated above. You must complete all the three lines marked by "~~Fill this line~~".

Input Format
A positive integer N that denotes N houses and people.

The following N lines will contain two integers, x and y, each denoting the coordinates of the respective house.

Output Format
An integer, M, that denotes the minimum combined travel time of everyone. 

Input #1

4 
0 1
2 5 
3 1 
4 0 

Output #1

8

Explanation
The houses will have a travel-sum of 11, 13, 8, or 10. 8 is the minimum.



"""


import math
class point:
   def __init__(self,x,y):
      self.x=x
      self.y=y
    

points=[]
num=int(input());
for i in range(num):
   inp=input().split();
   x=int(inp[0])
   y=int(inp[1])
   points.append(point(x,y))

ave_x=0.0
ave_y=0.0

for i in range(num):
   ave_x += points[i].x;
   ave_y += points[i].y;


ave_x /= num;
ave_y /= num;

diff_x = points[0].x - ave_x;
diff_y = points[0].y - ave_y;

best = 0;
~~Fill this line~~

for i in range(0,num):
   diff_x = points[i].x - ave_x;
   diff_y = points[i].y - ave_y;

   ~~Fill this line~~

   if hold_dist < best_dist:
      best_dist = hold_dist;
      best = i;
   
best_pt = points[best];
total_dist = 0;

for i in range(0,num):
   diff_x = math.fabs(points[i].x-best_pt.x);
   diff_y = math.fabs(points[i].y-best_pt.y);
   ~~Fill this line~~
   
print(int(total_dist));

